package model;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.List;

public class SinhVienDao {
	List<SinhVien> ls = new ArrayList<SinhVien>(
//			Arrays.asList(
//					new SinhVien("1", "SV1", true, new Date(), "K1", "Ha Noi", new ArrayList<MonHoc>()),
//					new SinhVien("2", "SV2", true, new Date(), "K2", "Ha Noi", new ArrayList<MonHoc>()),
//					new SinhVien("3", "SV3", true, new Date(), "K3", "Ha Noi", new ArrayList<MonHoc>())
//					)
	);
	public int add(SinhVien sv) {
		ls.add(sv) ;
		return 1 ;
	}
	public int remove(SinhVien sv) {
		ls.remove(sv) ;
		return 1 ;
	}
	public List<SinhVien> getAllSinhVien() {
		return ls ;
	}
	public void setLs(List<SinhVien> ls) {
		this.ls = ls;
	}
	public int delSVbyID(String ma) {
		for(SinhVien sv : ls) {
			if(sv.getMaSinhVien().equalsIgnoreCase(ma)) {
				ls.remove(sv) ;
				return 1 ;
			}
		}
		return -1 ;
	}
	public SinhVien getSinhVienById(String id) {
		for(SinhVien sv : ls) {
			if(sv.getMaSinhVien().equalsIgnoreCase(id)) {
				return sv ;
			}
		}
		return null ;
	}
	public boolean kiemTraIdDaTonTaiHayChua(String id) {
		for (SinhVien sinhVien : ls) {
			if(sinhVien.getMaSinhVien().equals(id)) {
				return true ;
			}
		}
		return false ;
	}
	public List<SinhVien> timSinhVienTheoTen(String ten) {
		List<SinhVien> dsSinhVienCanTim = new ArrayList<SinhVien>() ;
		for(SinhVien sv : ls) {
			String tenSinhVienLowerCase = sv.getHoVaTen().toLowerCase() ;
			String tenCanTimLowerCase = ten.toLowerCase() ;
			if(tenSinhVienLowerCase.contains(tenCanTimLowerCase)) {
				dsSinhVienCanTim.add(sv) ;
			}
		}
		return dsSinhVienCanTim ;
	}
	
	public void themDiemChoSinhVien(String maSV, MonHoc monHoc) {
		for(SinhVien sv : ls) {
			if(sv.getMaSinhVien().equalsIgnoreCase(maSV)) {
				sv.getMonHoc().add(monHoc);
				break;
			}
		}
	}
	public int SoLuongSinhVien() {
		return ls.size() ;
	}
	public void SapXepSinhVienTheoTen() {
		Collections.sort(ls, new Comparator<SinhVien>() {
            @Override
            public int compare(SinhVien sv1, SinhVien sv2) {
                String ten1 = layTen(sv1.getHoVaTen());
                String ten2 = layTen(sv2.getHoVaTen());

                // Sử dụng compareToIgnoreCase để so sánh không phân biệt hoa thường
                return ten1.compareToIgnoreCase(ten2);
            }

            private String layTen(String hoVaTen) {
                // Tách họ và tên đệm, chỉ giữ lại tên
                String[] parts = hoVaTen.split("\\s+");
                if (parts.length > 0) {
                    return parts[parts.length - 1];
                } else {
                    return hoVaTen;
                }
            }
        });
	}
}
