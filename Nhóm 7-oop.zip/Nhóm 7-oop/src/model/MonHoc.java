 package model;

public class MonHoc {
	@Override
	public String toString() {
		return "MH," + maMonHoc + "," + tenMonHoc + "," + soTinChi + ","
				+ loaiMon + "," + diem;
	}
	String maMonHoc ;
	String tenMonHoc ;
	int soTinChi ;
	String loaiMon ;
	String diem;
	public MonHoc(String maMonHoc, String tenMonHoc, int soTinChi, String loaiMon, String diem) {
		this.maMonHoc = maMonHoc;
		this.tenMonHoc = tenMonHoc;
		this.soTinChi = soTinChi;
		this.loaiMon = loaiMon;
		this.diem = diem;
	}
	
	public String getDiem() {
		return diem;
	}

	public void setDiem(String diem) {
		this.diem = diem;
	}

	public String getMaMonHoc() {
		return maMonHoc;
	}
	public void setMaMonHoc(String maMonHoc) {
		this.maMonHoc = maMonHoc;
	}
	public String getTenMonHoc() {
		return tenMonHoc;
	}
	public void setTenMonHoc(String tenMonHoc) {
		this.tenMonHoc = tenMonHoc;
	}
	public int getSoTinChi() {
		return soTinChi;
	}
	public void setSoTinChi(int soTinChi) {
		this.soTinChi = soTinChi;
	}
	public String getLoaiMon() {
		return loaiMon;
	}
	public void setLoaiMon(String loaiMon) {
		this.loaiMon = loaiMon;
	}
	
	
}
