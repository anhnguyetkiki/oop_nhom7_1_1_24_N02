package model;

import java.util.ArrayList;

public class Lop {
	private String tenLop ;

	public Lop(String tenLop) {
		this.tenLop = tenLop;
	}

	public String getTenLop() {
		return tenLop;
	}

	public void setTenLop(String tenLop) {
		this.tenLop = tenLop;
	}

	@Override
	public String toString() {
		return "Lop [tenLop=" + tenLop + "]";
	}
	public static ArrayList getDSLop() {
		String[] arrLop = {"CNTT1","CNTT2",
				"CNTT3","CNTT4","CNTT5","CNTT-VJ1","CNTT-VJ2",
				"CNTT-VJ3","CNTT-VJ4","CNTT-VJ5"
						} ;	
		ArrayList<Lop> listLop = new ArrayList<Lop>() ;
		for (String ten_lop : arrLop) {
			Lop l = new Lop(ten_lop) ;
			listLop.add(l) ;
		}
		return listLop ;
	}
}
