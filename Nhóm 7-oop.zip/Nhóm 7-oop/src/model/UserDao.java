package model;

import java.util.ArrayList;
import java.util.List;

public class UserDao {
	public static List<User> ls = new ArrayList<User>() ;
	public UserDao() {
		ls.add(new User("1" , "1" ,  true)) ;
		ls.add(new User("admin" , "12345" ,  true)) ;
		ls.add(new User("teo" , "12345" ,  true)) ;
		ls.add(new User("nminh" , "12345" ,  true)) ;
		ls.add(new User("admin1" , "12345" ,  true)) ;
		ls.add(new User("admin2" , "12345" ,  true)) ;
		ls.add(new User(" " , " " ,  true)) ;
	}
	public boolean checkLogin(String username , String password) {
		for (User u: ls) {
			if(u.getUsername().equals(username) && u.getPassword().equals(password)) {
				return true ;
			}
		}
		return false ;
	}
}
