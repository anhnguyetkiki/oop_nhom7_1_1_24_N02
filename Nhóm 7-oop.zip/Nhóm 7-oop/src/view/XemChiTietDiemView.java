package view;

import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.border.EmptyBorder;
import javax.swing.event.TableModelEvent;
import javax.swing.event.TableModelListener;
import javax.swing.table.DefaultTableModel;

import model.MonHoc;
import model.SinhVien;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class XemChiTietDiemView extends JFrame {

    private static final long serialVersionUID = 1L;
    private JPanel contentPane;
    private JTable table;
    private SinhVien sinhVien;
    private JLabel lbMaSinhVien;
    private JLabel lbHoVaTen;
    private JButton btn_Xoa;

    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    XemChiTietDiemView frame = new XemChiTietDiemView();
                    frame.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    public XemChiTietDiemView(SinhVien sinhVien) {
        this();
        this.sinhVien = sinhVien;
        lbMaSinhVien.setText("Mã Sinh Viên: " + sinhVien.getMaSinhVien());
        lbHoVaTen.setText("Họ Tên: " + sinhVien.getHoVaTen());
        fillDataTable();
    }

    public XemChiTietDiemView() {
        setVisible(true);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setBounds(100, 100, 1022, 588);
        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

        setContentPane(contentPane);
        contentPane.setLayout(null);

        lbMaSinhVien = new JLabel("Mã Sinh Viên :");
        lbMaSinhVien.setFont(new Font("Tahoma", Font.PLAIN, 18));
        lbMaSinhVien.setBounds(64, 23, 487, 29);
        contentPane.add(lbMaSinhVien);

        lbHoVaTen = new JLabel("Họ Và Tên :");
        lbHoVaTen.setFont(new Font("Tahoma", Font.PLAIN, 18));
        lbHoVaTen.setBounds(64, 62, 487, 29);
        contentPane.add(lbHoVaTen);

        table = new JTable();
        table.setFont(new Font("Tahoma", Font.PLAIN, 15));
        table.setModel(new EditableTableModel(
                new Object[][] { { null, null, null, null, null }, { null, null, null, null, null },
                        { null, null, null, null, null }, { null, null, null, null, null }, },
                new String[] { "Mã Môn", "Tên Môn", "Số Tín Chỉ", "Loại Môn", "Điểm" }));

        table.getColumnModel().getColumn(0).setPreferredWidth(62);
        JScrollPane scrollPane = new JScrollPane(table);
        scrollPane.setBounds(64, 132, 626, 139);
        contentPane.add(scrollPane);

        JButton btn_CapNhat = new JButton("Cập Nhật ");
        btn_CapNhat.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        	}
        });
        btn_CapNhat.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                lbMaSinhVien.setText("Mã Sinh Viên: " + sinhVien.getMaSinhVien());
                lbHoVaTen.setText("Họ Tên: " + sinhVien.getHoVaTen());
                fillDataTable();
                JOptionPane.showMessageDialog(btn_CapNhat, "Cập nhật thành công");
            }
        });
        btn_CapNhat.setFont(new Font("Tahoma", Font.PLAIN, 18));
        btn_CapNhat.setBounds(356, 318, 129, 41);
        contentPane.add(btn_CapNhat);
        
        btn_Xoa = new JButton("Xóa");
        btn_Xoa.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		int selectedRow = table.getSelectedRow();

                if (selectedRow != -1) { // Kiểm tra xem có dòng nào được chọn không
                    // Lấy mã môn học từ dòng được chọn
                    String maMonHoc = (String) table.getValueAt(selectedRow, 0);

                    // Xóa môn học từ danh sách môn học của sinh viên
                    MonHoc monHocToRemove = null;
                    for (MonHoc mh : sinhVien.getMonHoc()) {
                        if (mh.getMaMonHoc().equals(maMonHoc)) {
                            monHocToRemove = mh;
                            break;
                        }
                    }

                    if (monHocToRemove != null) {
                        sinhVien.getMonHoc().remove(monHocToRemove);
                        // Cập nhật bảng sau khi xóa
                        fillDataTable();
                    }
                }
        	}
        });
        btn_Xoa.setFont(new Font("Tahoma", Font.PLAIN, 18));
        btn_Xoa.setBounds(511, 318, 129, 41);
        contentPane.add(btn_Xoa);

        // Thêm sự kiện vào constructor để xử lý khi ô bảng được chỉnh sửa
        table.getModel().addTableModelListener(new TableModelListener() {
            @Override
            public void tableChanged(TableModelEvent e) {
                int row = e.getFirstRow();
                int column = e.getColumn();
                if (column == 4) { // Chỉ xử lý cột "Điểm"
                    // Lấy giá trị mới từ bảng và cập nhật dữ liệu sinhVien
                    Object newValue = table.getValueAt(row, column);
                    sinhVien.getMonHoc().get(row).setDiem((String) newValue);
                }
            }
        });
        
    }

    public void fillDataTable() {
        DefaultTableModel model = (DefaultTableModel) table.getModel();
        model.setRowCount(0); // clear
        for (MonHoc mh : sinhVien.getMonHoc()) {
            Object rowData[] = new Object[5];
            rowData[0] = mh.getMaMonHoc();
            rowData[1] = mh.getTenMonHoc();
            rowData[2] = mh.getSoTinChi();
            rowData[3] = mh.getLoaiMon();
            rowData[4] = mh.getDiem();
            model.addRow(rowData);
        }
    }

    // Lớp mở rộng DefaultTableModel để cho phép chỉnh sửa ô
    class EditableTableModel extends DefaultTableModel {
        @Override
        public boolean isCellEditable(int row, int column) {
            // Chỉ cho phép chỉnh sửa ô cột "Điểm"
            return column == 4;
        }

        public EditableTableModel(Object[][] data, Object[] columnNames) {
            super(data, columnNames);
        }
    }
}