package view;

import java.awt.Color;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import model.User;
import model.UserDao;

import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.ImageIcon;

public class DangKyView extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField txtTenDangNhap;
	private JTextField txtMatKhau;
	private JTextField txtNhacLaiMatKhau;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					DangKyView frame = new DangKyView();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public DangKyView() {
		setVisible(true);
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 740, 469);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Đăng Ký"); lblNewLabel.setForeground(Color.blue);
		lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 27));
		lblNewLabel.setBounds(334, 28, 177, 41);
		contentPane.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("Tên Đăng Nhập :"); 
		lblNewLabel_1.setFont(new Font("Tahoma", Font.PLAIN, 16));lblNewLabel_1.setForeground(Color.black);
		lblNewLabel_1.setBounds(235, 102, 165, 41);
		contentPane.add(lblNewLabel_1);
		
		JLabel lblNewLabel_1_1 = new JLabel("Mật Khẩu :");
		lblNewLabel_1_1.setFont(new Font("Tahoma", Font.PLAIN, 16)); lblNewLabel_1_1.setForeground(Color.black);
		lblNewLabel_1_1.setBounds(235, 182, 165, 41);
		contentPane.add(lblNewLabel_1_1);
		
		JLabel lblNewLabel_1_1_1 = new JLabel("Nhắc lại mật khẩu :"); lblNewLabel_1_1_1.setForeground(Color.BLACK);
		lblNewLabel_1_1_1.setFont(new Font("Tahoma", Font.PLAIN, 16));
		lblNewLabel_1_1_1.setBounds(235, 247, 165, 41);
		contentPane.add(lblNewLabel_1_1_1);
		
		txtTenDangNhap = new JTextField();
		txtTenDangNhap.setBounds(410, 104, 165, 41);
		contentPane.add(txtTenDangNhap);
		txtTenDangNhap.setColumns(10);
		
		txtMatKhau = new JTextField();
		txtMatKhau.setColumns(10);
		txtMatKhau.setBounds(410, 184, 165, 41);
		contentPane.add(txtMatKhau);
		
		txtNhacLaiMatKhau = new JTextField();
		txtNhacLaiMatKhau.setColumns(10);
		txtNhacLaiMatKhau.setBounds(410, 249, 165, 41);
		contentPane.add(txtNhacLaiMatKhau);
		
		JButton btn_dangKy = new JButton("Đăng Ký");
		btn_dangKy.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(checkValidForm()) {
					if(txtMatKhau.getText().equals(txtNhacLaiMatKhau.getText()) == false) {
						JOptionPane.showMessageDialog(btn_dangKy, "Mật Khẩu không khớp");
					}else {
						User user = new User(txtTenDangNhap.getText() , txtMatKhau.getText() , true) ;
						UserDao.ls.add(user) ;
						JOptionPane.showMessageDialog(btn_dangKy, "Đăng kí thành công ") ;
						setVisible(false) ;
					}
				}else {
					JOptionPane.showMessageDialog(btn_dangKy, "Bạn chưa nhập đầy đủ thông tin !") ;
				}
			}
		});
		btn_dangKy.setFont(new Font("Tahoma", Font.PLAIN, 16));
		btn_dangKy.setBounds(349, 324, 146, 47);
		contentPane.add(btn_dangKy);
		
		JLabel lblNewLabel_2 = new JLabel("New label");
		lblNewLabel_2.setIcon(new ImageIcon(DangKyView.class.getResource("/view/a.jpg")));
		lblNewLabel_2.setBounds(10, 0, 716, 422);
		contentPane.add(lblNewLabel_2);
	}
	public boolean checkValidForm() {
		if(txtTenDangNhap.getText().isEmpty() || txtMatKhau.getText().isEmpty() || txtNhacLaiMatKhau.getText().isEmpty()) {
			return false ;
		}
		return true ;
	}
}
