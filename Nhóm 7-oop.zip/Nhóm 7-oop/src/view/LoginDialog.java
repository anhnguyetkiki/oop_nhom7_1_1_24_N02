package view;

import java.awt.BorderLayout;
import java.awt.FlowLayout;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import model.UserDao;

import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.ImageIcon;
import javax.swing.JTextField;
import javax.swing.JPasswordField;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class LoginDialog extends JDialog {

	private static final long serialVersionUID = 1L;
	private final JPanel contentPanel = new JPanel();
	private JTextField textField_dangNhap;
	private JPasswordField textFied_MatKhau;

	/**
	 * Launch the application.
	 */
	
	
	public static void main(String[] args) {
		try {
			LoginDialog dialog = new LoginDialog();
			dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
			dialog.setVisible(true);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Create the dialog.
	 */
	public LoginDialog() {
		
		setBounds(100, 100, 679, 413);
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		contentPanel.setLayout(null);
		setLocationRelativeTo(null);
		
		JLabel lblNewLabel = new JLabel("Đăng Nhập Hệ Thống");
		lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblNewLabel.setBounds(230, 22, 197, 32);
		contentPanel.add(lblNewLabel);
		{
			JLabel lblNewLabel_1 = new JLabel("");
			lblNewLabel_1.setIcon(new ImageIcon(LoginDialog.class.getResource("/view/security.jpg")));
			lblNewLabel_1.setBounds(49, 64, 264, 263);
			contentPanel.add(lblNewLabel_1);
		}
		
		JLabel lblNewLabel_2 = new JLabel("Tên Đăng Nhập : ");
		lblNewLabel_2.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblNewLabel_2.setBounds(288, 93, 147, 50);
		contentPanel.add(lblNewLabel_2);
		
		textField_dangNhap = new JTextField();
		textField_dangNhap.setBounds(429, 93, 197, 38);
		contentPanel.add(textField_dangNhap);
		textField_dangNhap.setColumns(10);
		
		JLabel lblNewLabel_3 = new JLabel("Mật Khẩu : ");
		lblNewLabel_3.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblNewLabel_3.setBounds(288, 173, 139, 32);
		contentPanel.add(lblNewLabel_3);
		
		textFied_MatKhau = new JPasswordField();
		textFied_MatKhau.setBounds(429, 173, 197, 32);
		contentPanel.add(textFied_MatKhau);
		
		
		JButton button_DangNhap = new JButton("Đăng Nhập");
		
		button_DangNhap.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(checkValidateForm()) {
					String username = textField_dangNhap.getText() ;
					String pass = new String(textFied_MatKhau.getPassword()) ;
					UserDao dao = new UserDao();
					if(dao.checkLogin(username, pass)) {
						QuanLyDiemView view = new QuanLyDiemView() ;
						view.setVisible(true) ;
						LoginDialog.this.dispose() ;
 					}else {
						JOptionPane.showMessageDialog(button_DangNhap, "Ten dang nhap hoac mat khau khong dung") ;
					}
				}else {
					JOptionPane.showMessageDialog(button_DangNhap, "Ban chua nhap ten dang nhap hoac mat khau ");
				}
			}
		});
		button_DangNhap.setFont(new Font("Tahoma", Font.PLAIN, 14));
		button_DangNhap.setBounds(376, 232, 139, 32);
		contentPanel.add(button_DangNhap);
		
		JButton button_Huy = new JButton("Hủy");
		button_Huy.setFont(new Font("Tahoma", Font.PLAIN, 14));
		button_Huy.setBounds(537, 232, 103, 29);
		contentPanel.add(button_Huy);
		
		JButton btn_dangKi = new JButton("Đăng ký"); 
		btn_dangKi.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				DangKyView dangKyView = new DangKyView() ;
			}
			
		});
		btn_dangKi.setFont(new Font("Tahoma", Font.PLAIN, 14));
		btn_dangKi.setBounds(468, 275, 103, 32);
		contentPanel.add(btn_dangKi);
		{
			JPanel buttonPane = new JPanel();
			buttonPane.setLayout(new FlowLayout(FlowLayout.RIGHT));
			getContentPane().add(buttonPane, BorderLayout.SOUTH);
			{
				JButton okButton = new JButton("OK");
				okButton.setActionCommand("OK");
				buttonPane.add(okButton);
				getRootPane().setDefaultButton(okButton);
			}
			{
				JButton cancelButton = new JButton("Cancel");
				cancelButton.setActionCommand("Cancel");
				buttonPane.add(cancelButton);
			}
		}
	}
	public boolean checkValidateForm() {
		if(textField_dangNhap.getText().isEmpty() || textFied_MatKhau.getText().isEmpty()) {
			return false ;
		}
		return true ;
	}
}
