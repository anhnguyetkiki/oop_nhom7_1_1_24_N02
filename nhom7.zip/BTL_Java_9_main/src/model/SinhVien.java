package model;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class SinhVien {
	String maSinhVien ;
	String hoVaTen ;
	boolean gioiTinh ;
	Date ngaySinh ;
	String lop ;
	String queQuan ;
	public SinhVien(String maSinhVien, String hoVaTen, boolean gioiTinh, Date ngaySinh, String lop, String queQuan,
			ArrayList<MonHoc> monHoc) {
		super();
		this.maSinhVien = maSinhVien;
		this.hoVaTen = hoVaTen;
		this.gioiTinh = gioiTinh;
		this.ngaySinh = ngaySinh;
		this.lop = lop;
		this.queQuan = queQuan;
		this.monHoc = monHoc;
	}
	
	private SimpleDateFormat date_format = new SimpleDateFormat("dd/MM/yyyy") ;
	
	@Override
	public String toString() {
		return "SV," +maSinhVien + "," + hoVaTen + "," + (gioiTinh ? "1" : "0") + ","
				+ date_format.format(ngaySinh) + "," + lop + "," + queQuan + "," + "\n" + convertListMonHocToString(monHoc);
	}
	
	private String convertListMonHocToString(List<MonHoc> listMonHoc) {
		String result = "";
		for (MonHoc mh : listMonHoc) {
			result = result + mh.toString() +"\n";
		}
		return result;
	}
	
	List<MonHoc> monHoc  = new ArrayList<MonHoc>();
	public SinhVien() {
		
	}
	public String getMaSinhVien() {
		return maSinhVien;
	}
	public void setMaSinhVien(String maSinhVien) {
		this.maSinhVien = maSinhVien;
	}
	public String getHoVaTen() {
		return hoVaTen;
	}
	public void setHoVaTen(String hoVaTen) {
		this.hoVaTen = hoVaTen;
	}
	public boolean isGioiTinh() {
		return gioiTinh;
	}
	public void setGioiTinh(boolean gioiTinh) {
		this.gioiTinh = gioiTinh;
	}
	public Date getNgaySinh() {
		return ngaySinh;
	}
	public void setNgaySinh(Date ngaySinh) {
		this.ngaySinh = ngaySinh;
	}
	public String getLop() {
		return lop;
	}
	public void setLop(String lop) {
		this.lop = lop;
	}
	public  List<MonHoc> getMonHoc() {
		 if (monHoc == null) {
	            monHoc= new ArrayList<>(); // Khởi tạo danh sách nếu chưa tồn tại
	        }
	        return monHoc;
	}
	public void setMonHoc(List<MonHoc> monHoc) {
		this.monHoc = monHoc;
	}
	public String getQueQuan() {
		return queQuan;
	}
	public void setQueQuan(String queQuan) {
		this.queQuan = queQuan;
	}
	
}
