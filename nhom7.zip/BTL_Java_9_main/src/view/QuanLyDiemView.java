package view;
import javax.swing.table.DefaultTableModel;

import java.awt.Color;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import model.Lop;
import model.MonHoc;
import model.SinhVien;
import model.SinhVienDao;

import model.Tinh;
import view.ThemDiemView.OnAddMarkListener;
import view.button.ButtonEditor;
import view.button.ButtonRenderer;
import view.button.OnButtonClickListener;

import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.imageio.ImageIO;
import javax.swing.ButtonGroup;
import javax.swing.ImageIcon;
import java.awt.Font;
import java.awt.Image;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.swing.JRadioButton;
import javax.swing.JTextArea;
import javax.swing.JComboBox;
import javax.swing.JFileChooser;
import javax.swing.JTextField;
import javax.swing.KeyStroke;
import javax.swing.JSeparator;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JTable;
import javax.swing.JScrollPane;
import javax.swing.table.DefaultTableModel;
import javax.swing.JPasswordField;
import java.awt.event.ActionListener;
import java.awt.event.InputEvent;
import java.awt.event.KeyEvent;
import java.awt.event.ActionEvent;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JMenu;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
public class QuanLyDiemView extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private ButtonGroup btn_group ;
	private JComboBox comboBox_QueQuan;
	private JTextField txtMaSinhVien;
	private JTextField txtHoVaTen;
	private JTextField txtNgaySinh;
	private JComboBox    comboBox_Lop;
	private JTable table;
	public String strHinhAnh;
	SimpleDateFormat date_format = new SimpleDateFormat("dd/MM/yyyy") ;
	public static SinhVienDao dao = new SinhVienDao() ;
	private JRadioButton rdNam;
	private JRadioButton rdNu;
	int checkId = 0 ;
	/**
	 * Launch the application.
	 */
	
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					QuanLyDiemView frame = new QuanLyDiemView();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public QuanLyDiemView() {
		setVisible(true);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 1272, 677);
		
		JMenuBar menuBar = new JMenuBar();
		setJMenuBar(menuBar);
		
		JMenu menuFile = new JMenu("File");
		menuBar.add(menuFile);
		
		JMenuItem menuItemOpen = new JMenuItem("Open",KeyEvent.VK_O); // gach chan chu O
		menuItemOpen.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_O , InputEvent.CTRL_DOWN_MASK));
		menuItemOpen.addActionListener(new ActionListener() {
		    @Override
		    public void actionPerformed(ActionEvent e) {
		        JFileChooser fileChooser = new JFileChooser();
		        fileChooser.setDialogTitle("Chọn file để mở");
		        int userSelection = fileChooser.showOpenDialog(QuanLyDiemView.this);

		        if (userSelection == JFileChooser.APPROVE_OPTION) {
		            File fileToOpen = fileChooser.getSelectedFile();
		            try {
						loadFromFile(fileToOpen);
					} catch (ParseException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
		        }
		    }
		});
		menuFile.add(menuItemOpen);
		
		JMenuItem menuItemSave = new JMenuItem("Save",KeyEvent.VK_S);
		menuItemSave.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_S , InputEvent.CTRL_DOWN_MASK));
		menuItemSave.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				System.out.println("aaa");
				JFileChooser fileChooser = new JFileChooser();
		        fileChooser.setDialogTitle("Chọn nơi lưu file");
		        int userSelection = fileChooser.showSaveDialog(QuanLyDiemView.this);

		        if (userSelection == JFileChooser.APPROVE_OPTION) {
		            File fileToSave = fileChooser.getSelectedFile();
		            saveToFile(fileToSave);
		        }
			}
		});
		
		menuFile.add(menuItemSave);
		
		JMenu menuAbout = new JMenu("About");
		menuBar.add(menuAbout);
		
		JMenuItem menuItemAboutMe = new JMenuItem("About me",KeyEvent.VK_A);
		menuItemAboutMe.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_A , InputEvent.CTRL_DOWN_MASK));
		menuItemAboutMe.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JOptionPane.showMessageDialog(menuItemAboutMe, "Update by : "
						+ "NguyenThiAnhNguyet\nNguyen Thi Mai\n" );
			}
		});
		menuAbout.add(menuItemAboutMe);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel_1 = new JLabel("Phần Mềm Quản Lý Điểm");
		lblNewLabel_1.setBounds(458, 10, 303, 79);
		lblNewLabel_1.setFont(new Font("Tahoma", Font.PLAIN, 26));
		contentPane.add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("Mã Sinh Viên :");
		lblNewLabel_2.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblNewLabel_2.setBounds(47, 67, 121, 55);
		contentPane.add(lblNewLabel_2);
		
		JLabel lblNewLabel_2_1 = new JLabel("Họ Và Tên :");
		lblNewLabel_2_1.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblNewLabel_2_1.setBounds(47, 117, 121, 55);
		contentPane.add(lblNewLabel_2_1);
		
		JLabel lblNewLabel_2_1_1 = new JLabel("Giới Tính :");
		lblNewLabel_2_1_1.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblNewLabel_2_1_1.setBounds(47, 166, 94, 55);
		contentPane.add(lblNewLabel_2_1_1);
		
		 rdNam = new JRadioButton("Nam");
		rdNam.setFont(new Font("Tahoma", Font.PLAIN, 18));
		rdNam.setBounds(145, 183, 73, 21);
		contentPane.add(rdNam);
		
		 rdNu = new JRadioButton("Nữ");
		rdNu.setFont(new Font("Tahoma", Font.PLAIN, 18));
		rdNu.setBounds(233, 183, 103, 21);
		contentPane.add(rdNu);
		
		btn_group = new ButtonGroup() ;
		btn_group.add(rdNam);
		btn_group.add(rdNu);
		
		JLabel lblNewLabel = new JLabel("Quê Quán : ");
		lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblNewLabel.setBounds(47, 231, 121, 21);
		contentPane.add(lblNewLabel);
		
		 comboBox_QueQuan = new JComboBox();
		 comboBox_QueQuan.addItem("");
		 ArrayList<Tinh> listTinh = Tinh.getDSTinh();
			for (Tinh tinh : listTinh) {
				comboBox_QueQuan.addItem(tinh.getTenTinh());
			}
		comboBox_QueQuan.setBounds(160, 232, 121, 24);
		contentPane.add(comboBox_QueQuan);
		
		JLabel lblNewLabel_2_1_1_1 = new JLabel("Ngày Sinh :");
		lblNewLabel_2_1_1_1.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblNewLabel_2_1_1_1.setBounds(354, 79, 94, 55);
		contentPane.add(lblNewLabel_2_1_1_1);
		
		txtMaSinhVien = new JTextField();
		txtMaSinhVien.setBounds(180, 83, 121, 33);
		contentPane.add(txtMaSinhVien);
		txtMaSinhVien.setColumns(10);
		
		txtHoVaTen = new JTextField();
		txtHoVaTen.setColumns(10);
		txtHoVaTen.setBounds(160, 132, 121, 33);
		contentPane.add(txtHoVaTen);
		
		txtNgaySinh = new JTextField();
		txtNgaySinh.setColumns(10);
		txtNgaySinh.setBounds(468, 89, 121, 33);
		contentPane.add(txtNgaySinh);
		
		JLabel lblNewLabel_2_1_1_1_1 = new JLabel("Lớp :");
		lblNewLabel_2_1_1_1_1.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblNewLabel_2_1_1_1_1.setBounds(354, 132, 94, 55);
		contentPane.add(lblNewLabel_2_1_1_1_1);
		
	    comboBox_Lop = new JComboBox();
		comboBox_Lop.addItem("") ;
		ArrayList<Lop> listLop = Lop.getDSLop();
		for (Lop lop : listLop) {
			comboBox_Lop.addItem(lop.getTenLop());
		}
		comboBox_Lop.setBounds(437, 148, 103, 24);
		contentPane.add(comboBox_Lop);
		
		JSeparator separator = new JSeparator();
		separator.setBounds(620, 244, 1, 0);
		contentPane.add(separator);
		
		JSeparator separator_2 = new JSeparator();
		separator_2.setBounds(620, 79, 0, 237);
		contentPane.add(separator_2);
		
		JButton btn_Reset = new JButton("Reset"); 
		btn_Reset.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		btn_Reset.setBackground(Color.WHITE);
		btn_Reset.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				comboBox_Lop.setSelectedIndex(-1);
				comboBox_QueQuan.setSelectedIndex(-1);
				txtMaSinhVien.setText("");
				txtNgaySinh.setText("");
				txtHoVaTen.setText("");
				rdNam.isSelected() ;
				
			}
		});
		btn_Reset.setFont(new Font("Tahoma", Font.PLAIN, 18));
		btn_Reset.setBounds(354, 222, 85, 38);
		contentPane.add(btn_Reset);
		
		JButton btnLuu = new JButton("Lưu");
		btnLuu.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				if(validateForm()  ) {
					try {	
						 SinhVien sv = getModel() ;

						if(dao.kiemTraIdDaTonTaiHayChua(sv.getMaSinhVien()) == false) {
							if(dao.add(sv) > 0 ) {
								JOptionPane.showMessageDialog(QuanLyDiemView.this, "Luu thanh cong") ;
								fillDataTable() ;
							}else {
								JOptionPane.showMessageDialog(btnLuu, "Luu khong thanh cong") ;
							}
						}else {
							JOptionPane.showMessageDialog(btnLuu, "Ma Sinh Vien Da Ton Tai");
						}
					} catch (ParseException e1) {
						// TODO Auto-generated catch block
						JOptionPane.showMessageDialog(btnLuu, "Loi , xem lai phan ngay thang nam sinh") ;
					}
				}else {
					JOptionPane.showMessageDialog(btnLuu, "Ban chua nhap day du thong tin");
				}
			}

			

			
		});
		btnLuu.setFont(new Font("Tahoma", Font.PLAIN, 18));
		btnLuu.setBounds(485, 225, 85, 38);
		contentPane.add(btnLuu);
		
		JButton btn_Sua = new JButton("Sửa");
		btn_Sua.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				// JOptionPane.showMessageDialog(btn_Sua, "Chọn sinh viên muốn sửa ! ");
				hienThiSinhVienDangChon();
				checkId = 1 ;
			}
		});
		btn_Sua.setFont(new Font("Tahoma", Font.PLAIN, 18));
		btn_Sua.setBounds(354, 278, 85, 38);
		contentPane.add(btn_Sua);
		
		JButton btn_Xoa = new JButton("Xóa");
		btn_Xoa.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		btn_Xoa.addMouseListener(new MouseAdapter() {
		    @Override
		    public void mouseClicked(MouseEvent e) {
		        try {
		            SinhVien sv = getThiSinhDangChon();
		            DefaultTableModel model = (DefaultTableModel) table.getModel();
		            int soLuongDong = model.getRowCount();

		            for (int i = 0; i < soLuongDong; i++) {
		                String id = model.getValueAt(i, 0) + "";
		                if (id.equals(sv.getMaSinhVien())) {
		                    int confirm = JOptionPane.showConfirmDialog(btn_Xoa, "Bạn có chắc chắn muốn xóa sinh viên này?", "Xác nhận xóa", JOptionPane.YES_NO_OPTION);
		                    
		                    if (confirm == JOptionPane.YES_OPTION) {
		                        model.removeRow(i);
		                        // Thực hiện xóa sinh viên trong CSDL nếu cần thiết
		                         dao.remove(sv) ;
		                        break;
		                    }
		                }
		            }
		        } catch (ParseException e1) {
		            JOptionPane.showMessageDialog(btn_Xoa, "Chưa chọn sinh viên");
		        }
		    }
		});
		btn_Xoa.setFont(new Font("Tahoma", Font.PLAIN, 18));
		btn_Xoa.setBounds(485, 278, 85, 38);
		contentPane.add(btn_Xoa);
		
		JButton btn_timKiem = new JButton("Tìm Kiếm");
		btn_timKiem.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		btn_timKiem.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				try {
					if(!txtHoVaTen.getText().isEmpty()) {
						String tenCanTim = txtHoVaTen.getText() ;
						List<SinhVien> dsSVCanTim = dao.timSinhVienTheoTen(tenCanTim) ;
						DefaultTableModel model = (DefaultTableModel) table.getModel() ;
						model.setRowCount(0); // clear 
						for(SinhVien sv : dsSVCanTim) {
							Object rowData[] = new Object[6] ; 
							rowData[0] = sv.getMaSinhVien() ;
							rowData[1] = sv.getHoVaTen() ;
							rowData[2] = sv.isGioiTinh()?"Nam":"Nu";
							rowData[3] = date_format.format(sv.getNgaySinh()) ;
							
							rowData[4] = sv.getLop() ;
							rowData[5] = sv.getQueQuan() ;
							model.addRow(rowData);
						}
					}else if(!txtMaSinhVien.getText().isEmpty()) {
						DefaultTableModel model = (DefaultTableModel) table.getModel() ;
						model.setRowCount(0); // clear 
						SinhVien svCanTim = dao.getSinhVienById(txtMaSinhVien.getText()) ;
						if(svCanTim == null ) {
							JOptionPane.showMessageDialog(btn_timKiem, "Khong tim thay") ;
						}
						Object rowData[] = new Object[6] ;
						rowData[0] = svCanTim.getMaSinhVien() ;
						rowData[1] = svCanTim.getHoVaTen() ;
						rowData[2] = svCanTim.isGioiTinh()?"Nam":"Nu";
						rowData[3] = date_format.format(svCanTim.getNgaySinh()) ;
						
						rowData[4] = svCanTim.getLop() ;
						rowData[5] = svCanTim.getQueQuan() ;
						model.addRow(rowData);
					}
				}catch(Exception ex) {
					JOptionPane.showMessageDialog(btn_timKiem, "Bạn chưa nhập tên hoặc mã sinh viên đúng để tìm kiếm") ;
				}
			}
		});
		btn_timKiem.setFont(new Font("Tahoma", Font.PLAIN, 18));
		btn_timKiem.setBounds(608, 222, 128, 38);
		contentPane.add(btn_timKiem);
		
		JButton btn_themDiem = new JButton("Thêm Điểm");
		btn_themDiem.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		btn_themDiem.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				ThemDiemView themDiemView = new ThemDiemView(
						new OnAddMarkListener() {
							@Override
							public void onAddMark(String maSV, MonHoc monHoc) {
								dao.themDiemChoSinhVien(maSV, monHoc);
								System.out.println(dao.getSinhVienById(maSV));
							}
						}) ;
				
			}
		});
		btn_themDiem.setFont(new Font("Tahoma", Font.PLAIN, 18));
		btn_themDiem.setBounds(763, 276, 128, 38);
		contentPane.add(btn_themDiem);
		
		
		
		table = new JTable();
		
		table.setFont(new Font("Tahoma", Font.PLAIN, 16));
		table.setRowHeight(25);
		String cotChiTiet = "Xem Chi Tiết";
		String nutChiTiet = "Chi Tiết";
		table.setModel(new MyTableModel(
			new Object[][] {
				{null, null, null, null, null, null, nutChiTiet},
				{null, null, null, null, null, null, nutChiTiet},
				{null, null, null, null, null, null, nutChiTiet},
			},
			new String[] {
				"M\u00E3 Sinh Vi\u00EAn", "H\u1ECD V\u00E0 T\u00EAn", "Gi\u1EDBi T\u00EDnh", "Ng\u00E0y Sinh", "L\u1EDBp", "Qu\u00EA Qu\u00E1n", cotChiTiet
			}
		));
		
		table.getColumn(cotChiTiet).setCellRenderer(new ButtonRenderer());
		table.getColumn(cotChiTiet).setCellEditor(
				new ButtonEditor(new JCheckBox(),  new OnButtonClickListener() {
					@Override
					public void onClick() {
						// click nut chi tiet
						try {
							XemChiTietDiemView xemChiTietDiemView = new XemChiTietDiemView(
									getThiSinhDangChon()
									) ;
						} catch (ParseException e) {
							// TODO Auto-generated catch block
							JOptionPane.showMessageDialog(btn_themDiem, "Thao tác lỗi") ;
						}
					}
					
				}));
		
		
		JScrollPane scrollPane = new JScrollPane(table);
		
		scrollPane.setBounds(82, 365, 1065, 203);
		contentPane.add(scrollPane);
		
		JButton btnNewButton = new JButton("New button");
		btnNewButton.setBounds(651, 234, 85, 21);
		contentPane.add(btnNewButton);
		
		JButton btn_DSSV = new JButton("DSSV");
		btn_DSSV.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				fillDataTable(); 
			}
		});
		btn_DSSV.setFont(new Font("Tahoma", Font.PLAIN, 18));
		btn_DSSV.setBounds(753, 222, 128, 38);
		contentPane.add(btn_DSSV);
		
		JButton btn_CapNhat = new JButton("Cập Nhật");
		btn_CapNhat.addMouseListener(new MouseAdapter() {
		    @Override
		    public void mouseClicked(MouseEvent e) {
		        if (validateForm()) {
		            try {
		                SinhVien sv = getThiSinhDangChon();
		                int soLuongDong = table.getRowCount();

		                for (int i = 0; i < soLuongDong; i++) {
		                    String id = table.getValueAt(i, 0) + "";
		                    if (id.equals(sv.getMaSinhVien())) {
		                        String newMaSinhVien = txtMaSinhVien.getText();

		                        // Kiểm tra xem mã sinh viên mới đã tồn tại trong bảng chưa
		                        boolean duplicate = false;
		                        for (int j = 0; j < soLuongDong; j++) {
		                            if (j != i && newMaSinhVien.equals(table.getValueAt(j, 0) + "")) {
		                                duplicate = true;
		                                break;
		                            }
		                        }

		                        if (!duplicate) {
		                            table.setValueAt(newMaSinhVien, i, 0);
		                            table.setValueAt(txtHoVaTen.getText(), i, 1);
		                            String gioiTinh = rdNam.isSelected() ? "Nam" : "Nữ";
		                            table.setValueAt(gioiTinh, i, 2);
		                            table.setValueAt(date_format.format(date_format.parse(txtNgaySinh.getText())), i, 3);
		                            table.setValueAt(comboBox_Lop.getSelectedItem(), i, 4);
		                            table.setValueAt(comboBox_QueQuan.getSelectedItem(), i, 5);
		                        } else {
		                            JOptionPane.showMessageDialog(btnLuu, "Mã Sinh Viên đã tồn tại trong bảng!");
		                        }
		                        break;
		                    }
		                }
		            } catch (ParseException e1) {
		                JOptionPane.showMessageDialog(btnLuu, "Lỗi khi cập nhật");
		            }
		        } else {
		            JOptionPane.showMessageDialog(btnLuu, "Bạn chưa nhập đầy đủ thông tin");
		        }
		    }
		});
		btn_CapNhat.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		btn_CapNhat.setFont(new Font("Tahoma", Font.PLAIN, 18));
		btn_CapNhat.setBounds(608, 276, 128, 38);
		contentPane.add(btn_CapNhat);
		
		JLabel lblNewLabel_3 = new JLabel(" ");
		lblNewLabel_3.setIcon(new ImageIcon(QuanLyDiemView.class.getResource("/view/logo2.jpg")));
		lblNewLabel_3.setBounds(930, 67, 225, 249);
		contentPane.add(lblNewLabel_3);
		
		JButton btn_ThongKe = new JButton("Thống Kê");
		btn_ThongKe.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				JOptionPane.showMessageDialog(btn_ThongKe, "Số lượng sinh viên là : " + dao.SoLuongSinhVien());
			}
		});
		btn_ThongKe.setFont(new Font("Tahoma", Font.PLAIN, 18));
		btn_ThongKe.setBounds(215, 278, 121, 38);
		contentPane.add(btn_ThongKe);
		
		JButton btn_SapXep = new JButton("Sắp Xếp");
		btn_SapXep.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				dao.SapXepSinhVienTheoTen(); 
				fillDataTable(); 
			}
		});
		btn_SapXep.setFont(new Font("Tahoma", Font.PLAIN, 18));
		btn_SapXep.setBounds(82, 278, 121, 38);
		contentPane.add(btn_SapXep);
		
		fillDataTable(); 
	}
	public SinhVien getModel() throws ParseException {
		SinhVien sv = new SinhVien() ;
		sv.setMaSinhVien(txtMaSinhVien.getText());
		sv.setHoVaTen(txtHoVaTen.getText());
		boolean gioiTinh = false ;
		if(rdNam.isSelected()) {
			gioiTinh = true ;
		}
		sv.setGioiTinh(gioiTinh);
		sv.setQueQuan((String)comboBox_QueQuan.getSelectedItem());
		sv.setLop((String)comboBox_Lop.getSelectedItem());
		sv.setNgaySinh(date_format.parse(txtNgaySinh.getText()));
		
		return sv ;
	}
	public void fillDataTable() {
		DefaultTableModel model = (DefaultTableModel) table.getModel() ;
		model.setRowCount(0); // clear 
		for(SinhVien sv : dao.getAllSinhVien()) {
			Object rowData[] = new Object[7] ; 
			rowData[0] = sv.getMaSinhVien() ;
			rowData[1] = sv.getHoVaTen() ;
			rowData[2] = sv.isGioiTinh()?"Nam":"Nu";
			rowData[3] = date_format.format(sv.getNgaySinh()) ;
			
			rowData[4] = sv.getLop() ;
			rowData[5] = sv.getQueQuan() ;
			rowData[6] = "Chi Tiết";
			model.addRow(rowData);
		}
	}
	

	public  SinhVien getThiSinhDangChon() throws ParseException {
		DefaultTableModel model_table = (DefaultTableModel) table.getModel();
		int i_row = table.getSelectedRow();

		String maThiSinh = String.valueOf(model_table.getValueAt(i_row, 0) + "");

		SinhVien sv = dao.getSinhVienById(maThiSinh);
		return sv ;
	}
	public void hienThiSinhVienDangChon() {
		try {
			SinhVien sv = getThiSinhDangChon() ; 
			txtMaSinhVien.setText(sv.getMaSinhVien());
			txtHoVaTen.setText(sv.getHoVaTen());
			String sNgaySinh = sv.getNgaySinh().getDate()+"/" + (sv.getNgaySinh().getMonth() + 1) + "/"
					+ (sv.getNgaySinh().getYear() + 1900);
			txtNgaySinh.setText(sNgaySinh);
			if(sv.isGioiTinh() == true) {
				rdNam.setSelected(true);
			}else {
				rdNu.setSelected(true);
			}
			comboBox_QueQuan.setSelectedItem(sv.getQueQuan());
			comboBox_Lop.setSelectedItem(sv.getLop());
			
			
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			JOptionPane.showMessageDialog(this, "Chưa chọn thí sinh ") ;
		}
		
	}
	public boolean validateForm() {
		if(txtMaSinhVien.getText().isEmpty() || txtHoVaTen.getText().isEmpty() || txtNgaySinh.getText().isEmpty() || comboBox_Lop.getSelectedIndex()  < 0 || comboBox_QueQuan.getSelectedIndex()<0 ) {
			return false ;
		}
		return true;
	}
	public class MyTableModel extends DefaultTableModel {
	    private static final long serialVersionUID = 1L;

	    public MyTableModel(Object[][] data, Object[] columnNames) {
	        super(data, columnNames);
	    }

	    @Override
	    public boolean isCellEditable(int row, int column) {
	        // Cho phép ô "Chi Tiết" có thể chỉnh sửa
	        return column == getColumnCount() - 1;
	    }
	}
	private void saveToFile(File file) {
	    try (BufferedWriter writer = new BufferedWriter(new FileWriter(file))) {
        
	        List<SinhVien> ls = dao.getAllSinhVien();
	        for (SinhVien sv: ls) {
	        	writer.write(sv.toString());
	        	writer.newLine();
	        }

	        JOptionPane.showMessageDialog(this, "Lưu thành công!");
	    } catch (IOException e) {
	        JOptionPane.showMessageDialog(this, "Lưu không thành công: " + e.getMessage());
	    }
	}
	private void loadFromFile(File file) throws ParseException {
	    try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
	        DefaultTableModel model = (DefaultTableModel) table.getModel();
	        model.setRowCount(0); // Xóa dữ liệu cũ

	        String line;
	        SinhVien sv = null;
	        ArrayList<SinhVien> listSinhVien = new ArrayList<SinhVien>();
	        while ((line = reader.readLine()) != null) {
	        	boolean dongTrang = line.isBlank();
	        	if (!dongTrang) {
	        		String[] rowData = line.split(",");
	        		switch (rowData[0]) {
	        		case "SV":
	        			Date ns = date_format.parse(rowData[4]);
	        			boolean gt = Integer.parseInt(rowData[3]) == 1;
	        			sv = new SinhVien(
	        					rowData[1],
	        					rowData[2],
	        					        gt,
	        							ns,
	        					rowData[5],
	        					rowData[6],
	        					new ArrayList<MonHoc>()
	        					);
	        			break;
	        		case "MH":
	        			MonHoc mh = new MonHoc(
	        					rowData[1],
	        					rowData[2],
	        					Integer.parseInt(rowData[3]),
	        					rowData[4],
	        					rowData[5]
	        					);
	        			if (sv != null) {
	        				sv.getMonHoc().add(mh);
	        			}
	        			break;
	        		}
	        	} else {
	        		if (sv != null) {
	        			listSinhVien.add(sv);
	        			sv = null;
	        		}
	        	}
	        }
	        System.out.println(listSinhVien.toString());
	        dao.setLs(listSinhVien);
	        fillDataTable();

	        JOptionPane.showMessageDialog(this, "Mở thành công!");
	    } catch (IOException e) {
	        JOptionPane.showMessageDialog(this, "Mở không thành công: " + e.getMessage());
	    }
	}
}
