package view;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import model.MonHoc;
import model.SinhVien;

import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JComboBox;
import javax.swing.JButton;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class ThemDiemView extends JFrame {
	
	public interface OnAddMarkListener {
		public void onAddMark(String maSV, MonHoc monHoc);
	}

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField txtMaMon;
	private JTextField txtTenMon;
	private JTextField txtSoTinChi;
	private JTextField txtDiem;
	private JTextField txtMaSV;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ThemDiemView frame = new ThemDiemView();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	
	private OnAddMarkListener onAddMarkListener;
	
	public ThemDiemView(OnAddMarkListener onAddMarkListener) {
		this();
		this.onAddMarkListener = onAddMarkListener;
	}

	/**
	 * Create the frame.
	 */
	public ThemDiemView() {
		setVisible(true);
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 786, 391);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Mã Môn : ");
		lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 23));
		lblNewLabel.setBounds(49, 50, 146, 33);
		contentPane.add(lblNewLabel);
		
		JLabel lblTnMn = new JLabel("Tên Môn :");
		lblTnMn.setFont(new Font("Tahoma", Font.PLAIN, 23));
		lblTnMn.setBounds(49, 92, 146, 33);
		contentPane.add(lblTnMn);
		
		JLabel lblNewLabel_1_1 = new JLabel("Số Tín Chỉ : ");
		lblNewLabel_1_1.setFont(new Font("Tahoma", Font.PLAIN, 23));
		lblNewLabel_1_1.setBounds(49, 135, 146, 33);
		contentPane.add(lblNewLabel_1_1);
		
		JLabel lblNewLabel_1_1_1 = new JLabel("Loại Môn :");
		lblNewLabel_1_1_1.setFont(new Font("Tahoma", Font.PLAIN, 23));
		lblNewLabel_1_1_1.setBounds(49, 178, 146, 33);
		contentPane.add(lblNewLabel_1_1_1);
		
		txtMaMon = new JTextField();
		txtMaMon.setBounds(196, 52, 146, 31);
		contentPane.add(txtMaMon);
		txtMaMon.setColumns(10);
		
		txtTenMon = new JTextField();
		txtTenMon.setColumns(10);
		txtTenMon.setBounds(196, 94, 146, 31);
		contentPane.add(txtTenMon);
		
		txtSoTinChi = new JTextField();
		txtSoTinChi.setColumns(10);
		txtSoTinChi.setBounds(196, 141, 146, 31);
		contentPane.add(txtSoTinChi);
		
		JComboBox cbLoaiMon = new JComboBox();
		String arrLoaiMon[] = {"Đại Cương" , "Cơ Sở Chuyên Ngành" , "Chuyên Ngành"} ;
		for (String string : arrLoaiMon) {
			cbLoaiMon.addItem(string ) ;
		}
		cbLoaiMon.setBounds(196, 188, 146, 22);
		contentPane.add(cbLoaiMon);
		
		JLabel lblNewLabel_1_1_1_1 = new JLabel("Điểm :");
		lblNewLabel_1_1_1_1.setFont(new Font("Tahoma", Font.PLAIN, 23));
		lblNewLabel_1_1_1_1.setBounds(49, 217, 146, 33);
		contentPane.add(lblNewLabel_1_1_1_1);
		
		txtDiem = new JTextField();
		txtDiem.setColumns(10);
		txtDiem.setBounds(196, 220, 146, 31);
		contentPane.add(txtDiem);
		
		JButton btnNewButton = new JButton("Thêm");
		btnNewButton.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				String maSV = txtMaSV.getText().trim();
				if(!QuanLyDiemView.dao.kiemTraIdDaTonTaiHayChua(maSV)) {
					JOptionPane.showMessageDialog(btnNewButton, "Sinh Viên không tồn tại !");
					return ;
				}
				else {
					try {
				        int soTinChi = Integer.parseInt(txtSoTinChi.getText().trim());

				        // Check if soTinChi is less than or equal to 0
				        if (soTinChi <= 0) {
				            JOptionPane.showMessageDialog(ThemDiemView.this, "Số tín chỉ phải là số nguyên dương.");
				            return ;
				        }
				    } catch (NumberFormatException ex) {
				        JOptionPane.showMessageDialog(ThemDiemView.this, "Số tín chỉ phải là số nguyên dương.");
				        return ;
				    }
					if (isMaMonHocDaTonTai(txtMaMon.getText().toString())) {
			            JOptionPane.showMessageDialog(ThemDiemView.this, "Mã môn đã tồn tại, vui lòng chọn mã môn khác.");
			            return ;
			            
			        }
			        // Check if the entered student ID exists
			        if (QuanLyDiemView.dao.kiemTraIdDaTonTaiHayChua(maSV) && isValidDiem(txtDiem.getText())) {
			            MonHoc monHoc = new MonHoc(
			                    txtMaMon.getText().toString(),
			                    txtTenMon.getText().toString(),
			                    Integer.parseInt(txtSoTinChi.getText()),
			                    cbLoaiMon.getSelectedItem().toString(),
			                    txtDiem.getText().toString()
			            );
			            onAddMarkListener.onAddMark(maSV, monHoc);
			            setVisible(false); // you can't see me!
			            dispose(); // Destroy the JFrame object
			        } else {
			            JOptionPane.showMessageDialog(ThemDiemView.this, "Sinh viên không tồn tại hoặc điểm không nằm trong khoảng hợp lệ ");
			        }
				}
			}
		});
		btnNewButton.setFont(new Font("Tahoma", Font.PLAIN, 18));
		btnNewButton.setBounds(210, 272, 143, 33);
		contentPane.add(btnNewButton);
		
		JLabel lblNewLabel_1 = new JLabel("Mã Sinh Viên:");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.PLAIN, 23));
		lblNewLabel_1.setBounds(49, 10, 146, 33);
		contentPane.add(lblNewLabel_1);
		
		txtMaSV = new JTextField();
		txtMaSV.setColumns(10);
		txtMaSV.setBounds(196, 16, 146, 31);
		contentPane.add(txtMaSV);
	}
	private boolean isValidDiem(String strDiem) {
        try {
            float diem = Float.parseFloat(strDiem);
            return diem >= 0 && diem <= 10;
        } catch (NumberFormatException e) {
            return false;
        }
    }
	// Kiểm tra xem mã môn đã tồn tại chưa
    private boolean isMaMonHocDaTonTai(String maMon) {
    	SinhVien sinhVien= QuanLyDiemView.dao.getSinhVienById(txtMaSV.getText().trim()) ;
        for (MonHoc mh : sinhVien.getMonHoc()) {
            if (mh.getMaMonHoc().equalsIgnoreCase(maMon)) {
                return true;
            }
        }
        return false;
    }
}
