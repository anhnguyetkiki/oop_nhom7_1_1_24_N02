package view.button;

public interface OnButtonClickListener {
	public void onClick();
}
