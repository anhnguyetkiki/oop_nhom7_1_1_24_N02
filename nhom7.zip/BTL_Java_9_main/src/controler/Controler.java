package controler;

import javax.swing.JFrame;
import view.LoginDialog;

public class Controler {
    public LoginDialog loginDialog;

    public Controler(LoginDialog loginDialog) {
        this.loginDialog = loginDialog;
    }

    public static void main(String[] args) {
        // Tạo một đối tượng Controler
        Controler controler = new Controler(new LoginDialog());

        controler.loginDialog.setVisible(true);
    }
}